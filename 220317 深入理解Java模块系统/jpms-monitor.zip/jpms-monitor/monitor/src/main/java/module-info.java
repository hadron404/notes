module monitor {
	requires monitor.observer;
	requires monitor.observer.alpha;
	requires monitor.observer.beta;
	requires monitor.statistics;
	requires monitor.persistence;
	requires monitor.rest;
}
