module monitor.statistics {
	requires monitor.observer;
	exports monitor.statistics;
}
