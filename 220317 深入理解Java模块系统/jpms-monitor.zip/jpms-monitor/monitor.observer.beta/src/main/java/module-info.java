module monitor.observer.beta {
	requires monitor.observer;
	exports monitor.observer.beta;
}
