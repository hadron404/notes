module monitor.observer {
	exports monitor.observer;
}
