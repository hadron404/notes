package monitor.observer;

public interface ServiceObserver {

	DiagnosticDataPoint gatherDataFromService();

}
