module monitor.observer.alpha {
	requires monitor.observer;
	exports monitor.observer.alpha;
}
