module monitor.rest {
	requires spark.core;
	requires monitor.statistics;

	exports monitor.rest;
}
