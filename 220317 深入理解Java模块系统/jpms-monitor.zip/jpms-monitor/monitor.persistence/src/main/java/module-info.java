module monitor.persistence {
	requires monitor.statistics;
	exports monitor.persistence;
}
